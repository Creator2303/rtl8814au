#!/bin/bash
# This script sets up /etc/rc.local to persistently set TX power to 30 dBm for wlan0

# Create or overwrite /etc/rc.local
sudo bash -c 'cat > /etc/rc.local << EOF
#!/bin/bash
# rc.local

# Set TX power to 30 dBm for wlan0
iw dev wlan0 set txpower fixed 3000
iw dev wlan1 set txpower fixed 3000
iw dev wlan2 set txpower fixed 3000
iw dev wlan4 set txpower fixed 3000

exit 0
EOF'

# Make /etc/rc.local executable
sudo chmod +x /etc/rc.local

# Create rc-local.service if it doesn't exist
if [ ! -f /etc/systemd/system/rc-local.service ]; then
    sudo bash -c 'cat > /etc/systemd/system/rc-local.service << EOF
[Unit]
Description=/etc/rc.local Compatibility
ConditionPathExists=/etc/rc.local

[Service]
Type=forking
ExecStart=/etc/rc.local start
TimeoutSec=0
StandardOutput=tty
RemainAfterExit=yes
SysVStartPriority=99

[Install]
WantedBy=multi-user.target
EOF'
fi

# Reload systemd and enable rc-local service
sudo systemctl daemon-reload
sudo systemctl enable rc-local
sudo systemctl start rc-local

echo "rc.local has been set up to persistently set TX power to 30 dBm for wlan0."
