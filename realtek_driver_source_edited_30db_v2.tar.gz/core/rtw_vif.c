#include "rtw_vif.h"
#include <linux/ieee80211.h> // For ieee80211_hw and ieee80211_vif

void rtl8814au_add_interface(struct ieee80211_hw *hw, struct ieee80211_vif *vif) {
    printk(KERN_INFO "rtl8814au_add_interface called for hw: %p vif: %p\n", hw, vif);
    // Add your implementation logic here
}

void rtl8814au_remove_interface(struct ieee80211_hw *hw, struct ieee80211_vif *vif) {
    printk(KERN_INFO "rtl8814au_remove_interface called for hw: %p vif: %p\n", hw, vif);
    // Add your implementation logic here
}
