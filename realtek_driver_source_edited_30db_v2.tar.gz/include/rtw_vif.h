#include "rtw_vif.h"
#include <net/mac80211.h>

void rtl8814au_add_interface(struct ieee80211_hw *hw, struct ieee80211_vif *vif) {
    // Implementation here
}

void rtl8814au_remove_interface(struct ieee80211_hw *hw, struct ieee80211_vif *vif) {
    // Implementation here
}
